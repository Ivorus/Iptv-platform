<?php
require_once '../config.php';
if (!isLoggedIn() || !isAdmin()) redirect('../');
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Админ — STREAM MAX</title>
<link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;600;700;800;900&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --bg:#060610;--bg2:#0b0b1a;--bg3:#101025;--card:#12122a;--card2:#181835;
  --border:#1e1e42;--border2:#2a2a5a;
  --blue:#3d5afe;--blue2:#536dfe;--cyan:#00e5ff;--purple:#7c4dff;
  --gold:#ffc400;--green:#00e676;--red:#ff1744;
  --text:#e8eaf6;--muted:#7986cb;--pale:#c5cae9;
  --grad:linear-gradient(135deg,#3d5afe,#7c4dff);--r:12px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);}
::-webkit-scrollbar{width:5px;}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}

.layout{display:grid;grid-template-columns:240px 1fr;min-height:100vh;}

/* SIDEBAR */
.sb{background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto;}
.sb-logo{padding:22px 18px;border-bottom:1px solid var(--border);font-family:'Exo 2',sans-serif;font-size:18px;font-weight:900;letter-spacing:2px;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.sb-sec{padding:10px 8px 4px;}
.sb-lbl{font-size:9px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--muted);padding:0 10px;margin-bottom:5px;}
.sb-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;cursor:pointer;font-size:13px;font-weight:500;color:var(--muted);transition:all .15s;margin-bottom:2px;}
.sb-item:hover{background:var(--bg3);color:var(--text);}
.sb-item.on{background:rgba(61,90,254,.15);color:var(--blue2);}
.sb-icon{font-size:15px;width:20px;text-align:center;}
.sb-bot{margin-top:auto;padding:12px;border-top:1px solid var(--border);display:flex;align-items:center;gap:10px;}
.ava{width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;flex-shrink:0;background:var(--grad);}
.sb-uname{font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.sb-role{font-size:11px;color:var(--muted);}
.sb-out{background:none;border:none;color:var(--muted);cursor:pointer;font-size:16px;margin-left:auto;transition:color .2s;}
.sb-out:hover{color:var(--red);}

/* MAIN */
.main{background:var(--bg);padding:32px;overflow-y:auto;}
.page{display:none;}
.page.on{display:block;}
.ph{margin-bottom:26px;}
.ph h1{font-family:'Exo 2',sans-serif;font-size:30px;font-weight:900;letter-spacing:.5px;}
.ph p{color:var(--muted);font-size:13px;margin-top:3px;}

/* STAT CARDS */
.sc-g{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:28px;}
.sc{background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:20px;position:relative;overflow:hidden;}
.sc::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;}
.sc.blue::before{background:var(--grad);}
.sc.cyan::before{background:linear-gradient(90deg,var(--cyan),#00b0ff);}
.sc.green::before{background:var(--green);}
.sc.gold::before{background:linear-gradient(90deg,var(--gold),#ff6d00);}
.sc.purple::before{background:var(--purple);}
.sc-icon{font-size:22px;margin-bottom:8px;}
.sc-val{font-family:'Exo 2',sans-serif;font-size:34px;font-weight:900;line-height:1;}
.sc-lbl{font-size:12px;color:var(--muted);margin-top:3px;}

/* CARD */
.card{background:var(--card);border:1px solid var(--border);border-radius:var(--r);overflow:hidden;margin-bottom:18px;}
.card-head{padding:14px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.card-head h3{font-size:14px;font-weight:700;}

/* TABLE */
table{width:100%;border-collapse:collapse;}
th,td{padding:12px 18px;text-align:left;font-size:13px;}
th{background:var(--bg3);color:var(--muted);font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;}
tr:not(:last-child) td{border-bottom:1px solid var(--border);}
tr:hover td{background:rgba(255,255,255,.012);}

/* BADGE */
.badge{padding:3px 10px;border-radius:20px;font-size:10px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;display:inline-block;}
.b-on{background:rgba(0,230,118,.12);color:var(--green);}
.b-off{background:rgba(255,23,68,.12);color:var(--red);}

/* BUTTONS */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:10px 20px;border-radius:var(--r);font-family:'Inter',sans-serif;font-size:13px;font-weight:600;border:none;cursor:pointer;text-decoration:none;transition:all .2s;}
.btn-primary{background:var(--grad);color:#fff;}
.btn-primary:hover{opacity:.9;}
.btn-xs{padding:5px 11px;font-size:11px;border-radius:8px;}
.btn-green{background:rgba(0,230,118,.15);color:var(--green);}
.btn-green:hover{background:rgba(0,230,118,.25);}
.btn-red{background:rgba(255,23,68,.15);color:var(--red);}
.btn-red:hover{background:rgba(255,23,68,.25);}
.btn-blue{background:rgba(61,90,254,.15);color:var(--blue2);}
.btn-blue:hover{background:rgba(61,90,254,.25);}
.btn-gold{background:rgba(255,196,0,.15);color:var(--gold);}
.btn-gold:hover{background:rgba(255,196,0,.25);}
.btn-outline{background:transparent;border:1.5px solid var(--border2);color:var(--pale);}

.ab{display:flex;gap:5px;}

/* FORM */
.fg{margin-bottom:14px;}
.fg label{display:block;font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--muted);margin-bottom:6px;}
.fg input,.fg select{width:100%;background:var(--bg3);border:1.5px solid var(--border);border-radius:10px;padding:11px 13px;color:var(--text);font-family:'Inter',sans-serif;font-size:13px;outline:none;transition:border-color .2s;appearance:none;}
.fg input:focus,.fg select:focus{border-color:var(--blue);}
.fg input::placeholder{color:var(--border2);}
.fg-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.fg-grid .full{grid-column:1/-1;}
.fp{padding:22px;}

/* ACCESS LIST */
.acc-list{display:flex;flex-direction:column;gap:8px;max-height:340px;overflow-y:auto;padding-right:4px;}
.acc-row{display:flex;align-items:center;justify-content:space-between;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:10px 14px;}
.acc-name{display:flex;align-items:center;gap:10px;font-size:13px;font-weight:500;}
.toggle{width:40px;height:22px;border-radius:11px;background:var(--border2);border:none;cursor:pointer;position:relative;transition:background .2s;flex-shrink:0;}
.toggle.on{background:var(--blue);}
.toggle::after{content:'';position:absolute;width:16px;height:16px;background:#fff;border-radius:50%;top:3px;left:3px;transition:transform .2s;}
.toggle.on::after{transform:translateX(18px);}

/* OVERLAY */
.overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);backdrop-filter:blur(10px);z-index:1000;align-items:center;justify-content:center;padding:20px;}
.overlay.on{display:flex;}
.modal{background:var(--card2);border:1px solid var(--border2);border-radius:18px;padding:36px;width:100%;max-width:480px;position:relative;animation:mIn .3s ease;}
@keyframes mIn{from{opacity:0;transform:scale(.96);}to{opacity:1;transform:none;}}
.mx{position:absolute;top:14px;right:14px;background:var(--border);border:none;border-radius:50%;width:28px;height:28px;cursor:pointer;color:var(--text);font-size:14px;display:flex;align-items:center;justify-content:center;transition:background .2s;}
.mx:hover{background:var(--blue);}
.modal h2{font-family:'Exo 2',sans-serif;font-size:20px;font-weight:800;margin-bottom:4px;}
.modal .mp{color:var(--muted);font-size:13px;margin-bottom:20px;}

/* TOAST */
.toast{position:fixed;bottom:20px;right:20px;z-index:9999;background:var(--card2);border:1px solid var(--border2);border-radius:10px;padding:11px 15px;font-size:13px;font-weight:500;transform:translateX(130%);transition:transform .3s;box-shadow:0 8px 24px rgba(0,0,0,.5);max-width:280px;}
.toast.show{transform:translateX(0);}
.toast.ok{border-left:3px solid var(--green);}
.toast.err{border-left:3px solid var(--red);}
.toast.inf{border-left:3px solid var(--blue2);}
.empty{text-align:center;padding:40px;color:var(--muted);font-size:14px;}
</style>
</head>
<body>
<div class="layout">

<!-- SIDEBAR -->
<aside class="sb">
  <div class="sb-logo">STREAM MAX</div>
  <div class="sb-sec">
    <div class="sb-lbl">Главное</div>
    <div class="sb-item on" onclick="nav('dash',this)"><span class="sb-icon">📊</span>Дашборд</div>
    <div class="sb-item" onclick="nav('users',this)"><span class="sb-icon">👥</span>Пользователи</div>
    <div class="sb-item" onclick="nav('leads',this)"><span class="sb-icon">📋</span>Заявки</div>
  </div>
  <div class="sb-sec">
    <div class="sb-lbl">Контент</div>
    <div class="sb-item" onclick="nav('channels',this)"><span class="sb-icon">📺</span>Каналы</div>
    <div class="sb-item" onclick="nav('access',this)"><span class="sb-icon">🔐</span>Доступы</div>
  </div>
  <div class="sb-bot">
    <div class="ava"><?=mb_substr($user['name'],0,1,'UTF-8')?></div>
    <div><div class="sb-uname"><?=htmlspecialchars($user['name'])?></div><div class="sb-role">Администратор</div></div>
    <button class="sb-out" onclick="doLogout()" title="Выйти">⏻</button>
  </div>
</aside>

<!-- MAIN -->
<div class="main">

  <!-- DASHBOARD -->
  <div class="page on" id="p-dash">
    <div class="ph"><h1>Дашборд</h1><p>Обзор платформы в реальном времени</p></div>
    <div class="sc-g">
      <div class="sc blue"><div class="sc-icon">👥</div><div class="sc-val" id="s-users">—</div><div class="sc-lbl">Пользователей</div></div>
      <div class="sc green"><div class="sc-icon">✅</div><div class="sc-val" id="s-active">—</div><div class="sc-lbl">Активных</div></div>
      <div class="sc cyan"><div class="sc-icon">📺</div><div class="sc-val" id="s-chs">—</div><div class="sc-lbl">Каналов</div></div>
      <div class="sc gold"><div class="sc-icon">🔐</div><div class="sc-val" id="s-acc">—</div><div class="sc-lbl">Выданных доступов</div></div>
      <div class="sc purple"><div class="sc-icon">📋</div><div class="sc-val" id="s-leads">—</div><div class="sc-lbl">Заявок</div></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>Последние пользователи</h3></div>
      <table><thead><tr><th>Имя</th><th>Логин</th><th>Статус</th><th>Каналов</th></tr></thead>
      <tbody id="dash-tbl"><tr><td colspan="4" class="empty">Загрузка...</td></tr></tbody></table>
    </div>
  </div>

  <!-- USERS -->
  <div class="page" id="p-users">
    <div class="ph"><h1>Пользователи</h1><p>Управление учётными записями клиентов</p></div>
    <div class="card">
      <div class="card-head"><h3>Все пользователи</h3><button class="btn btn-primary" style="font-size:12px;padding:8px 16px;" onclick="openAddUser()">+ Добавить</button></div>
      <table><thead><tr><th>Имя</th><th>Логин</th><th>Email</th><th>Статус</th><th>Каналов</th><th>Дата</th><th>Действия</th></tr></thead>
      <tbody id="users-tbl"><tr><td colspan="7" class="empty">Загрузка...</td></tr></tbody></table>
    </div>
  </div>

  <!-- LEADS -->
  <div class="page" id="p-leads">
    <div class="ph"><h1>Заявки</h1><p>Заявки с лендинга</p></div>
    <div class="card">
      <div class="card-head"><h3>Все заявки</h3></div>
      <table><thead><tr><th>Имя</th><th>Телефон</th><th>Email</th><th>Устройство</th><th>Источник</th><th>Дата</th></tr></thead>
      <tbody id="leads-tbl"><tr><td colspan="6" class="empty">Загрузка...</td></tr></tbody></table>
    </div>
  </div>

  <!-- CHANNELS -->
  <div class="page" id="p-channels">
    <div class="ph"><h1>Каналы</h1><p>Добавление и управление каналами</p></div>
    <div class="card" style="margin-bottom:18px;">
      <div class="card-head"><h3>➕ Добавить канал</h3></div>
      <div class="fp">
        <div class="fg-grid">
          <div class="fg"><label>Название</label><input id="ch-name" type="text" placeholder="Первый Канал"></div>
          <div class="fg"><label>Категория</label>
            <select id="ch-cat">
              <option>📺 Новости</option><option>⚽ Спорт</option><option>🎬 Кино</option>
              <option>🎭 Сериалы</option><option>🧒 Детские</option><option>📚 Образование</option>
              <option>🎵 Музыка</option><option>🌍 Документальные</option>
            </select>
          </div>
          <div class="fg full"><label>Ссылка на поток (M3U8/HLS)</label><input id="ch-url" type="text" placeholder="https://stream.example.com/channel.m3u8"></div>
          <div class="fg"><label>Иконка (эмодзи)</label><input id="ch-icon" type="text" placeholder="📡" maxlength="4"></div>
          <div class="fg"><label>Цвет фона</label><input id="ch-color" type="color" value="#0d0d2e" style="height:44px;padding:4px 8px;cursor:pointer;"></div>
        </div>
        <button class="btn btn-primary" onclick="addChannel()">Добавить канал</button>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><h3>Список каналов</h3></div>
      <table><thead><tr><th>Канал</th><th>Категория</th><th>Поток</th><th>Действия</th></tr></thead>
      <tbody id="chs-tbl"><tr><td colspan="4" class="empty">Загрузка...</td></tr></tbody></table>
    </div>
  </div>

  <!-- ACCESS -->
  <div class="page" id="p-access">
    <div class="ph"><h1>Управление доступом</h1><p>Назначайте каналы пользователям</p></div>
    <div class="card">
      <div class="card-head"><h3>Доступы пользователей</h3></div>
      <table><thead><tr><th>Пользователь</th><th>Статус</th><th>Доступных каналов</th><th>Управление</th></tr></thead>
      <tbody id="acc-tbl"><tr><td colspan="4" class="empty">Загрузка...</td></tr></tbody></table>
    </div>
  </div>

</div><!-- /main -->
</div><!-- /layout -->

<!-- ACCESS MODAL -->
<div class="overlay" id="acc-ov">
  <div class="modal" style="max-width:500px">
    <button class="mx" onclick="closeOv('acc-ov')">×</button>
    <h2 id="acc-title">Доступы пользователя</h2>
    <p class="mp">Включите каналы которые должны быть доступны</p>
    <div class="acc-list" id="acc-list"></div>
    <div style="display:flex;gap:10px;margin-top:18px;">
      <button class="btn btn-primary" style="flex:1" onclick="saveAcc()">Сохранить</button>
      <button class="btn btn-outline" onclick="closeOv('acc-ov')">Отмена</button>
    </div>
  </div>
</div>

<!-- ADD USER MODAL -->
<div class="overlay" id="add-user-ov">
  <div class="modal">
    <button class="mx" onclick="closeOv('add-user-ov')">×</button>
    <h2>Добавить пользователя</h2>
    <p class="mp">Создать новый аккаунт вручную</p>
    <div class="fg"><label>Имя</label><input id="au-name" type="text" placeholder="Имя клиента"></div>
    <div class="fg"><label>Логин</label><input id="au-user" type="text" placeholder="username"></div>
    <div class="fg"><label>Email</label><input id="au-email" type="email" placeholder="email@mail.com"></div>
    <div class="fg"><label>Пароль</label><input id="au-pass" type="text" placeholder="Придумайте пароль"></div>
    <div id="au-err" style="color:var(--red);font-size:12px;margin-bottom:10px;display:none;"></div>
    <button class="btn btn-primary" style="width:100%;padding:13px;" onclick="addUser()">Создать аккаунт</button>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
const API = '../api/index.php';
let accUid = null, tmpAcc = {};

// NAV
function nav(sec, el) {
  document.querySelectorAll('.sb-item').forEach(i => i.classList.remove('on'));
  el.classList.add('on');
  document.querySelectorAll('.page').forEach(p => p.classList.remove('on'));
  document.getElementById('p-' + sec).classList.add('on');
  if (sec === 'dash')     loadDash();
  if (sec === 'users')    loadUsers();
  if (sec === 'leads')    loadLeads();
  if (sec === 'channels') loadChannels();
  if (sec === 'access')   loadAccess();
}

// LOAD DASH
async function loadDash() {
  const d = await api({ action: 'admin_stats' });
  if (!d.ok) return;
  document.getElementById('s-users').textContent  = d.users;
  document.getElementById('s-active').textContent = d.active;
  document.getElementById('s-chs').textContent    = d.channels;
  document.getElementById('s-acc').textContent    = d.accesses;
  document.getElementById('s-leads').textContent  = d.leads;
  document.getElementById('dash-tbl').innerHTML = d.recent.length
    ? d.recent.map(u => `<tr>
        <td><strong>${esc(u.name)}</strong></td>
        <td style="color:var(--muted)">@${esc(u.username)}</td>
        <td><span class="badge ${u.status==='active'?'b-on':'b-off'}">${u.status==='active'?'Активен':'Заблокирован'}</span></td>
        <td style="color:var(--cyan);font-weight:700">${u.ch_count}</td>
      </tr>`).join('')
    : '<tr><td colspan="4" class="empty">Нет пользователей</td></tr>';
}

// LOAD USERS
async function loadUsers() {
  const d = await api({ action: 'admin_users' });
  if (!d.ok) return;
  document.getElementById('users-tbl').innerHTML = d.users.length
    ? d.users.map(u => `<tr>
        <td><strong>${esc(u.name)}</strong></td>
        <td style="color:var(--muted)">@${esc(u.username)}</td>
        <td style="color:var(--muted);font-size:12px">${esc(u.email)}</td>
        <td><span class="badge ${u.status==='active'?'b-on':'b-off'}">${u.status==='active'?'Активен':'Заблокирован'}</span></td>
        <td style="color:var(--cyan);font-weight:700">${u.ch_count}</td>
        <td style="color:var(--muted);font-size:11px">${u.created_at.slice(0,10)}</td>
        <td><div class="ab">
          <button class="btn btn-xs ${u.status==='active'?'btn-red':'btn-green'}" onclick="toggleStatus(${u.id})">${u.status==='active'?'Заблок.':'Разблок.'}</button>
          <button class="btn btn-xs btn-blue" onclick="openAccess(${u.id},'${esc(u.name)}')">Доступы</button>
          <button class="btn btn-xs btn-red" onclick="deleteUser(${u.id})">Удалить</button>
        </div></td>
      </tr>`).join('')
    : '<tr><td colspan="7" class="empty">Нет пользователей</td></tr>';
}

// LOAD LEADS
async function loadLeads() {
  const d = await api({ action: 'admin_leads' });
  if (!d.ok) return;
  document.getElementById('leads-tbl').innerHTML = d.leads.length
    ? d.leads.map(l => `<tr>
        <td><strong>${esc(l.name||'—')}</strong></td>
        <td style="color:var(--cyan)">${esc(l.phone||'—')}</td>
        <td style="color:var(--muted);font-size:12px">${esc(l.email||'—')}</td>
        <td>${esc(l.device||'—')}</td>
        <td style="color:var(--muted)">${esc(l.source||'—')}</td>
        <td style="color:var(--muted);font-size:11px">${l.created_at.slice(0,16)}</td>
      </tr>`).join('')
    : '<tr><td colspan="6" class="empty">Заявок пока нет</td></tr>';
}

// LOAD CHANNELS
async function loadChannels() {
  const d = await api({ action: 'admin_channels' });
  if (!d.ok) return;
  document.getElementById('chs-tbl').innerHTML = d.channels.length
    ? d.channels.map(c => `<tr>
        <td><div style="display:flex;align-items:center;gap:10px">
          <div style="width:32px;height:32px;border-radius:8px;background:${esc(c.color)};display:flex;align-items:center;justify-content:center;font-size:16px;border:1px solid var(--border)">${c.icon}</div>
          <strong>${esc(c.name)}</strong></div></td>
        <td style="color:var(--muted)">${esc(c.category)}</td>
        <td style="color:var(--muted);font-size:11px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(c.url)}</td>
        <td><button class="btn btn-xs btn-red" onclick="deleteCh(${c.id})">Удалить</button></td>
      </tr>`).join('')
    : '<tr><td colspan="4" class="empty">Нет каналов. Добавьте первый!</td></tr>';
}

// LOAD ACCESS
async function loadAccess() {
  const d = await api({ action: 'admin_users' });
  if (!d.ok) return;
  document.getElementById('acc-tbl').innerHTML = d.users.length
    ? d.users.map(u => `<tr>
        <td><div style="display:flex;align-items:center;gap:10px">
          <div style="width:30px;height:30px;border-radius:50%;background:var(--grad);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700">${esc(u.name.charAt(0))}</div>
          <div><div style="font-weight:600">${esc(u.name)}</div><div style="color:var(--muted);font-size:11px">@${esc(u.username)}</div></div>
        </div></td>
        <td><span class="badge ${u.status==='active'?'b-on':'b-off'}">${u.status==='active'?'Активен':'Заблокирован'}</span></td>
        <td><span style="color:var(--cyan);font-weight:800;font-size:17px">${u.ch_count}</span></td>
        <td><button class="btn btn-xs btn-gold" onclick="openAccess(${u.id},'${esc(u.name)}')">✏️ Настроить</button></td>
      </tr>`).join('')
    : '<tr><td colspan="4" class="empty">Нет пользователей</td></tr>';
}

// ACTIONS
async function toggleStatus(uid) {
  const d = await api({ action: 'admin_toggle_status', user_id: uid });
  if (d.ok) { toast(d.status === 'active' ? 'Пользователь разблокирован' : 'Пользователь заблокирован', 'inf'); loadUsers(); loadDash(); }
}

async function deleteUser(uid) {
  if (!confirm('Удалить пользователя?')) return;
  const d = await api({ action: 'admin_delete_user', user_id: uid });
  if (d.ok) { toast('Пользователь удалён', 'inf'); loadUsers(); loadDash(); }
}

async function addChannel() {
  const name  = document.getElementById('ch-name').value.trim();
  const url   = document.getElementById('ch-url').value.trim();
  if (!name || !url) { toast('⚠️ Введите название и ссылку', 'err'); return; }
  const d = await api({
    action: 'admin_add_channel',
    name, url,
    category: document.getElementById('ch-cat').value,
    icon:     document.getElementById('ch-icon').value.trim() || '📡',
    color:    document.getElementById('ch-color').value
  });
  if (d.ok) {
    document.getElementById('ch-name').value = '';
    document.getElementById('ch-url').value = '';
    document.getElementById('ch-icon').value = '';
    toast('✅ Канал добавлен', 'ok'); loadChannels();
  }
}

async function deleteCh(cid) {
  if (!confirm('Удалить канал?')) return;
  const d = await api({ action: 'admin_delete_channel', channel_id: cid });
  if (d.ok) { toast('Канал удалён', 'inf'); loadChannels(); }
}

// ACCESS MODAL
async function openAccess(uid, name) {
  accUid = uid; tmpAcc = {};
  document.getElementById('acc-title').textContent = 'Доступы: ' + name;
  const d = await api({ action: 'admin_get_access', user_id: uid });
  if (!d.ok) return;
  d.granted.forEach(id => tmpAcc[id] = true);
  document.getElementById('acc-list').innerHTML = d.channels.length
    ? d.channels.map(c => `
      <div class="acc-row">
        <div class="acc-name"><span style="font-size:17px">${c.icon}</span>
          <div><div style="font-size:13px;font-weight:600">${esc(c.name)}</div>
          <div style="font-size:11px;color:var(--muted)">${esc(c.category)}</div></div>
        </div>
        <button class="toggle ${tmpAcc[c.id]?'on':''}" id="tg-${c.id}" onclick="toggleTg(${c.id},this)"></button>
      </div>`).join('')
    : '<p style="color:var(--muted);text-align:center;padding:20px">Нет добавленных каналов</p>';
  openOv('acc-ov');
}

function toggleTg(cid, btn) { tmpAcc[cid] = !tmpAcc[cid]; btn.classList.toggle('on'); }

async function saveAcc() {
  const ids = Object.keys(tmpAcc).filter(k => tmpAcc[k]);
  const d = await api({ action: 'admin_save_access', user_id: accUid, channel_ids: JSON.stringify(ids) });
  if (d.ok) { closeOv('acc-ov'); toast('✅ Доступы сохранены', 'ok'); loadAccess(); loadUsers(); loadDash(); }
}

// ADD USER MODAL
function openAddUser() {
  document.getElementById('au-name').value = '';
  document.getElementById('au-user').value = '';
  document.getElementById('au-email').value = '';
  document.getElementById('au-pass').value = '';
  document.getElementById('au-err').style.display = 'none';
  openOv('add-user-ov');
}

async function addUser() {
  const name = document.getElementById('au-name').value.trim();
  const username = document.getElementById('au-user').value.trim();
  const email = document.getElementById('au-email').value.trim();
  const password = document.getElementById('au-pass').value;
  const err = document.getElementById('au-err');
  if (!name || !username || !email || !password) { err.textContent = 'Заполните все поля'; err.style.display = 'block'; return; }
  const d = await api({ action: 'register', name, username, email, password });
  if (d.error) { err.textContent = d.error; err.style.display = 'block'; return; }
  closeOv('add-user-ov');
  toast('✅ Пользователь добавлен', 'ok');
  loadUsers(); loadDash();
}

// LOGOUT
async function doLogout() {
  await api({ action: 'logout' });
  window.location.href = '../';
}

// OVERLAY
function openOv(id)  { document.getElementById(id).classList.add('on'); }
function closeOv(id) { document.getElementById(id).classList.remove('on'); }
document.querySelectorAll('.overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) o.classList.remove('on'); });
});

// HELPERS
function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

async function api(data) {
  const form = new FormData();
  Object.entries(data).forEach(([k,v]) => form.append(k, v));
  try {
    const r = await fetch(API, { method: 'POST', body: form });
    return await r.json();
  } catch(e) { return { error: 'Ошибка соединения' }; }
}

function toast(msg, type = 'inf') {
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = 'toast ' + type + ' show';
  setTimeout(() => t.classList.remove('show'), 3500);
}

// INIT
loadDash();
</script>
</body>
</html>
