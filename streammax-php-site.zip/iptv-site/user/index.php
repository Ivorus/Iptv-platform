<?php
require_once '../config.php';
if (!isLoggedIn()) redirect('../');
if (isAdmin()) redirect('../admin/');
$user = currentUser();
if (!$user) redirect('../');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Мой кабинет — STREAM MAX</title>
<link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;600;700;800;900&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --bg:#060610;--bg2:#0b0b1a;--bg3:#101025;--card:#12122a;--card2:#181835;
  --border:#1e1e42;--border2:#2a2a5a;
  --blue:#3d5afe;--blue2:#536dfe;--cyan:#00e5ff;
  --green:#00e676;--red:#ff1744;
  --text:#e8eaf6;--muted:#7986cb;--pale:#c5cae9;
  --grad:linear-gradient(135deg,#3d5afe,#7c4dff);--r:12px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);}
::-webkit-scrollbar{width:5px;}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px;}

.layout{display:grid;grid-template-columns:220px 1fr;min-height:100vh;}
.sb{background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;position:sticky;top:0;height:100vh;}
.sb-logo{padding:22px 18px;border-bottom:1px solid var(--border);font-family:'Exo 2',sans-serif;font-size:18px;font-weight:900;letter-spacing:2px;background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.sb-sec{padding:10px 8px 4px;}
.sb-lbl{font-size:9px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--muted);padding:0 10px;margin-bottom:5px;}
.sb-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;cursor:pointer;font-size:13px;font-weight:500;color:var(--muted);transition:all .15s;margin-bottom:2px;}
.sb-item:hover{background:var(--bg3);color:var(--text);}
.sb-item.on{background:rgba(61,90,254,.15);color:var(--blue2);}
.sb-icon{font-size:15px;width:20px;text-align:center;}
.sb-bot{margin-top:auto;padding:12px;border-top:1px solid var(--border);display:flex;align-items:center;gap:10px;}
.ava{width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;flex-shrink:0;background:linear-gradient(135deg,#00b0ff,#00e5ff);color:#000;}
.sb-uname{font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.sb-role{font-size:11px;color:var(--muted);}
.sb-out{background:none;border:none;color:var(--muted);cursor:pointer;font-size:16px;margin-left:auto;transition:color .2s;}
.sb-out:hover{color:var(--red);}

.main{background:var(--bg);padding:32px;overflow-y:auto;}
.page{display:none;}
.page.on{display:block;}
.ph{margin-bottom:26px;}
.ph h1{font-family:'Exo 2',sans-serif;font-size:30px;font-weight:900;letter-spacing:.5px;}
.ph p{color:var(--muted);font-size:13px;margin-top:3px;}

/* CHANNEL GRID */
.tv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(165px,1fr));gap:14px;}
.ch-card{background:var(--card);border:1px solid var(--border);border-radius:var(--r);overflow:hidden;cursor:pointer;transition:all .2s;}
.ch-card:hover{border-color:var(--blue);transform:translateY(-3px);box-shadow:0 10px 24px rgba(61,90,254,.15);}
.ch-thumb{height:90px;display:flex;align-items:center;justify-content:center;font-size:32px;position:relative;}
.ch-badge{position:absolute;top:6px;right:6px;background:var(--red);color:#fff;font-size:8px;font-weight:800;padding:2px 6px;border-radius:3px;letter-spacing:.5px;}
.ch-info{padding:10px 12px;}
.ch-n{font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.ch-c{font-size:11px;color:var(--muted);margin-top:2px;}

/* PROFILE */
.card{background:var(--card);border:1px solid var(--border);border-radius:var(--r);overflow:hidden;}
.pr-info{padding:26px;}
.pr-head{display:flex;align-items:center;gap:16px;margin-bottom:26px;}
.pr-ava{width:58px;height:58px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;background:linear-gradient(135deg,#00b0ff,#00e5ff);color:#000;}
.pr-name{font-size:20px;font-weight:700;}
.pr-login{color:var(--muted);font-size:13px;margin-top:3px;}
.pr-row{display:flex;justify-content:space-between;align-items:center;padding:13px 14px;background:var(--bg3);border-radius:10px;margin-bottom:10px;}
.pr-lbl{font-size:13px;color:var(--muted);}
.pr-val{font-size:13px;font-weight:600;}

/* LOCKED */
.locked{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:55vh;text-align:center;gap:12px;}
.locked-icon{font-size:60px;opacity:.35;}
.locked h2{font-family:'Exo 2',sans-serif;font-size:26px;color:var(--muted);}
.locked p{color:var(--muted);font-size:14px;max-width:300px;line-height:1.6;}

/* PLAYER MODAL */
.overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.96);z-index:1000;align-items:center;justify-content:center;flex-direction:column;}
.overlay.on{display:flex;}
.pl-wrap{width:88vw;max-width:840px;}
.pl-head{display:flex;align-items:center;justify-content:space-between;padding:10px 0;}
.pl-title{font-family:'Exo 2',sans-serif;font-size:22px;font-weight:800;}
.pl-screen{width:100%;aspect-ratio:16/9;background:#000;border-radius:14px;overflow:hidden;border:1px solid var(--border2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;}
.pl-note{color:var(--muted);font-size:11px;margin-top:12px;text-align:center;word-break:break-all;padding:0 20px;}

.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:9px 18px;border-radius:var(--r);font-family:'Inter',sans-serif;font-size:13px;font-weight:600;border:none;cursor:pointer;text-decoration:none;transition:all .2s;}
.btn-close{background:var(--border);color:var(--text);border-radius:50%;width:32px;height:32px;padding:0;font-size:18px;}
.btn-close:hover{background:var(--red);}

.toast{position:fixed;bottom:20px;right:20px;z-index:9999;background:var(--card2);border:1px solid var(--border2);border-radius:10px;padding:11px 15px;font-size:13px;font-weight:500;transform:translateX(130%);transition:transform .3s;box-shadow:0 8px 24px rgba(0,0,0,.5);}
.toast.show{transform:translateX(0);}
.toast.inf{border-left:3px solid var(--blue2);}
</style>
</head>
<body>
<div class="layout">

<aside class="sb">
  <div class="sb-logo">STREAM MAX</div>
  <div class="sb-sec">
    <div class="sb-lbl">Меню</div>
    <div class="sb-item on" onclick="nav('tv',this)"><span class="sb-icon">📺</span>Мои каналы</div>
    <div class="sb-item" onclick="nav('profile',this)"><span class="sb-icon">👤</span>Профиль</div>
  </div>
  <div class="sb-bot">
    <div class="ava"><?=mb_substr($user['name'],0,1,'UTF-8')?></div>
    <div><div class="sb-uname"><?=htmlspecialchars($user['name'])?></div><div class="sb-role">Зритель</div></div>
    <button class="sb-out" onclick="doLogout()" title="Выйти">⏻</button>
  </div>
</aside>

<div class="main">

  <!-- TV -->
  <div class="page on" id="p-tv">
    <div class="ph"><h1>Мои Каналы</h1><p id="ch-count-lbl">Загрузка...</p></div>
    <div id="tv-wrap"></div>
  </div>

  <!-- PROFILE -->
  <div class="page" id="p-profile">
    <div class="ph"><h1>Профиль</h1><p>Информация о вашем аккаунте</p></div>
    <div class="card" style="max-width:460px;">
      <div class="pr-info">
        <div class="pr-head">
          <div class="pr-ava" id="pr-ava"><?=mb_substr($user['name'],0,1,'UTF-8')?></div>
          <div>
            <div class="pr-name" id="pr-name"><?=htmlspecialchars($user['name'])?></div>
            <div class="pr-login">@<?=htmlspecialchars($user['username'])?></div>
          </div>
        </div>
        <div class="pr-row"><span class="pr-lbl">Email</span><span class="pr-val"><?=htmlspecialchars($user['email'])?></span></div>
        <div class="pr-row"><span class="pr-lbl">Роль</span><span class="pr-val" style="color:var(--blue2)">Пользователь</span></div>
        <div class="pr-row"><span class="pr-lbl">Статус</span>
          <span class="pr-val" style="color:<?=$user['status']==='active'?'var(--green)':'var(--red)'?>"><?=$user['status']==='active'?'Активен':'Заблокирован'?></span>
        </div>
        <div class="pr-row"><span class="pr-lbl">Доступных каналов</span><span class="pr-val" id="pr-chs" style="color:var(--cyan)">—</span></div>
        <div class="pr-row"><span class="pr-lbl">Аккаунт создан</span><span class="pr-val" style="color:var(--muted);font-size:12px"><?=substr($user['created_at'],0,10)?></span></div>
      </div>
    </div>
  </div>

</div>
</div>

<!-- PLAYER -->
<div class="overlay" id="player-ov">
  <div class="pl-wrap">
    <div class="pl-head">
      <div class="pl-title" id="pl-title">Канал</div>
      <button class="btn btn-close" onclick="closeOv('player-ov')">×</button>
    </div>
    <div class="pl-screen">
      <div style="font-size:52px;opacity:.3;">📺</div>
      <div style="color:var(--muted);font-size:13px;">Подключение к потоку...</div>
    </div>
    <div class="pl-note" id="pl-url"></div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
const API = '../api/index.php';
let myChannels = [];

// NAV
function nav(sec, el) {
  document.querySelectorAll('.sb-item').forEach(i => i.classList.remove('on'));
  el.classList.add('on');
  document.querySelectorAll('.page').forEach(p => p.classList.remove('on'));
  document.getElementById('p-' + sec).classList.add('on');
  if (sec === 'tv')      loadTV();
  if (sec === 'profile') loadProfile();
}

// LOAD TV
async function loadTV() {
  const d = await api({ action: 'me' });
  if (!d.ok) { window.location.href = '../'; return; }
  myChannels = d.channels;
  const wrap = document.getElementById('tv-wrap');
  const lbl  = document.getElementById('ch-count-lbl');

  if (d.user.status === 'blocked') {
    lbl.textContent = '';
    wrap.innerHTML = `<div class="locked"><div class="locked-icon">🚫</div><h2>Аккаунт заблокирован</h2><p>Обратитесь к администратору по телефону или через сайт.</p></div>`;
    return;
  }

  if (!d.channels.length) {
    lbl.textContent = 'Каналы не назначены';
    wrap.innerHTML = `<div class="locked"><div class="locked-icon">📺</div><h2>Нет доступных каналов</h2><p>Администратор ещё не открыл вам доступ к каналам. Обратитесь в поддержку.</p></div>`;
    return;
  }

  lbl.textContent = `Доступно каналов: ${d.channels.length}`;
  wrap.innerHTML = `<div class="tv-grid">${d.channels.map(c => `
    <div class="ch-card" onclick="openPlayer('${esc(c.name)}','${esc(c.url)}')">
      <div class="ch-thumb" style="background:${esc(c.color)}">${c.icon}<div class="ch-badge">LIVE</div></div>
      <div class="ch-info"><div class="ch-n">${esc(c.name)}</div><div class="ch-c">${esc(c.category)}</div></div>
    </div>`).join('')}</div>`;
}

// LOAD PROFILE
async function loadProfile() {
  const d = await api({ action: 'me' });
  if (d.ok) document.getElementById('pr-chs').textContent = d.channels.length;
}

// PLAYER
function openPlayer(name, url) {
  document.getElementById('pl-title').textContent = name;
  document.getElementById('pl-url').textContent = 'Поток: ' + url;
  openOv('player-ov');
}

// LOGOUT
async function doLogout() {
  await api({ action: 'logout' });
  window.location.href = '../';
}

// OVERLAY
function openOv(id)  { document.getElementById(id).classList.add('on'); }
function closeOv(id) { document.getElementById(id).classList.remove('on'); }
document.getElementById('player-ov').addEventListener('click', e => {
  if (e.target === document.getElementById('player-ov')) closeOv('player-ov');
});

function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

async function api(data) {
  const form = new FormData();
  Object.entries(data).forEach(([k,v]) => form.append(k, v));
  try {
    const r = await fetch(API, { method: 'POST', body: form });
    return await r.json();
  } catch(e) { return { error: 'error' }; }
}

function toast(msg, type = 'inf') {
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = 'toast ' + type + ' show';
  setTimeout(() => t.classList.remove('show'), 3000);
}

loadTV();
</script>
</body>
</html>
