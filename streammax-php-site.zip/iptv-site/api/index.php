<?php
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // ── АВТОРИЗАЦИЯ ──────────────────────────────
    case 'login':
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        if (!$username || !$password) {
            jsonResponse(['error' => 'Заполните все поля']);
        }
        $stmt = db()->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, $user['password'])) {
            jsonResponse(['error' => 'Неверный логин или пароль']);
        }
        if ($user['status'] === 'blocked') {
            jsonResponse(['error' => 'Ваш аккаунт заблокирован. Обратитесь к администратору.']);
        }
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role']    = $user['role'];
        jsonResponse(['ok' => true, 'role' => $user['role'], 'name' => $user['name']]);

    // ── РЕГИСТРАЦИЯ ──────────────────────────────
    case 'register':
        $name     = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        if (!$name || !$username || !$email || !$password) {
            jsonResponse(['error' => 'Заполните все поля']);
        }
        if (strlen($password) < 6) {
            jsonResponse(['error' => 'Пароль минимум 6 символов']);
        }
        $check = db()->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $check->execute([$username, $email]);
        if ($check->fetch()) {
            jsonResponse(['error' => 'Логин или email уже занят']);
        }
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = db()->prepare("INSERT INTO users (name, username, email, password, role) VALUES (?, ?, ?, ?, 'user')");
        $stmt->execute([$name, $username, $email, $hash]);
        $uid = db()->lastInsertId();
        $_SESSION['user_id'] = $uid;
        $_SESSION['role']    = 'user';
        jsonResponse(['ok' => true, 'role' => 'user', 'name' => $name]);

    // ── ВЫХОД ────────────────────────────────────
    case 'logout':
        session_destroy();
        jsonResponse(['ok' => true]);

    // ── ТЕКУЩИЙ ПОЛЬЗОВАТЕЛЬ ─────────────────────
    case 'me':
        if (!isLoggedIn()) jsonResponse(['error' => 'not_logged_in']);
        $user = currentUser();
        if (!$user) jsonResponse(['error' => 'not_logged_in']);
        // Получаем каналы пользователя
        $cstmt = db()->prepare("
            SELECT c.* FROM channels c
            INNER JOIN user_channels uc ON uc.channel_id = c.id
            WHERE uc.user_id = ?
        ");
        $cstmt->execute([$user['id']]);
        $userChannels = $cstmt->fetchAll();
        unset($user['password']);
        jsonResponse(['ok' => true, 'user' => $user, 'channels' => $userChannels]);

    // ── ЗАЯВКА С ЛЕНДИНГА ────────────────────────
    case 'lead':
        $name   = sanitize($_POST['name'] ?? '');
        $phone  = sanitize($_POST['phone'] ?? '');
        $email  = sanitize($_POST['email'] ?? '');
        $device = sanitize($_POST['device'] ?? '');
        $source = sanitize($_POST['source'] ?? '');
        if (!$name || !$phone) jsonResponse(['error' => 'Введите имя и телефон']);
        $stmt = db()->prepare("INSERT INTO leads (name, phone, email, device, source) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $phone, $email, $device, $source]);
        jsonResponse(['ok' => true]);

    // ═══════════════════════════════════════════
    // ADMIN ACTIONS — только для администраторов
    // ═══════════════════════════════════════════

    case 'admin_stats':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $users    = db()->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
        $active   = db()->query("SELECT COUNT(*) FROM users WHERE role='user' AND status='active'")->fetchColumn();
        $channels = db()->query("SELECT COUNT(*) FROM channels")->fetchColumn();
        $accesses = db()->query("SELECT COUNT(*) FROM user_channels")->fetchColumn();
        $leads    = db()->query("SELECT COUNT(*) FROM leads")->fetchColumn();
        $recentUsers = db()->query("SELECT id,name,username,status,(SELECT COUNT(*) FROM user_channels WHERE user_id=users.id) as ch_count FROM users WHERE role='user' ORDER BY created_at DESC LIMIT 5")->fetchAll();
        jsonResponse(['ok'=>true,'users'=>$users,'active'=>$active,'channels'=>$channels,'accesses'=>$accesses,'leads'=>$leads,'recent'=>$recentUsers]);

    case 'admin_users':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $users = db()->query("SELECT id,name,username,email,status,created_at,(SELECT COUNT(*) FROM user_channels WHERE user_id=users.id) as ch_count FROM users WHERE role='user' ORDER BY created_at DESC")->fetchAll();
        jsonResponse(['ok'=>true,'users'=>$users]);

    case 'admin_toggle_status':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $uid = intval($_POST['user_id'] ?? 0);
        $user = db()->prepare("SELECT status FROM users WHERE id=?");
        $user->execute([$uid]);
        $row = $user->fetch();
        if (!$row) jsonResponse(['error' => 'Пользователь не найден']);
        $newStatus = $row['status'] === 'active' ? 'blocked' : 'active';
        db()->prepare("UPDATE users SET status=? WHERE id=?")->execute([$newStatus, $uid]);
        jsonResponse(['ok'=>true,'status'=>$newStatus]);

    case 'admin_delete_user':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $uid = intval($_POST['user_id'] ?? 0);
        db()->prepare("DELETE FROM users WHERE id=? AND role='user'")->execute([$uid]);
        jsonResponse(['ok'=>true]);

    case 'admin_channels':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $channels = db()->query("SELECT * FROM channels ORDER BY id DESC")->fetchAll();
        jsonResponse(['ok'=>true,'channels'=>$channels]);

    case 'admin_add_channel':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $name     = sanitize($_POST['name'] ?? '');
        $category = sanitize($_POST['category'] ?? '');
        $url      = trim($_POST['url'] ?? '');
        $icon     = sanitize($_POST['icon'] ?? '📡');
        $color    = sanitize($_POST['color'] ?? '#0d0d2e');
        if (!$name || !$url) jsonResponse(['error' => 'Введите название и ссылку']);
        $stmt = db()->prepare("INSERT INTO channels (name,category,url,icon,color) VALUES (?,?,?,?,?)");
        $stmt->execute([$name,$category,$url,$icon,$color]);
        jsonResponse(['ok'=>true,'id'=>db()->lastInsertId()]);

    case 'admin_delete_channel':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $cid = intval($_POST['channel_id'] ?? 0);
        db()->prepare("DELETE FROM channels WHERE id=?")->execute([$cid]);
        jsonResponse(['ok'=>true]);

    case 'admin_get_access':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $uid = intval($_GET['user_id'] ?? 0);
        $allChannels = db()->query("SELECT * FROM channels ORDER BY id")->fetchAll();
        $granted = db()->prepare("SELECT channel_id FROM user_channels WHERE user_id=?");
        $granted->execute([$uid]);
        $grantedIds = array_column($granted->fetchAll(), 'channel_id');
        jsonResponse(['ok'=>true,'channels'=>$allChannels,'granted'=>$grantedIds]);

    case 'admin_save_access':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $uid = intval($_POST['user_id'] ?? 0);
        $ids = json_decode($_POST['channel_ids'] ?? '[]', true);
        db()->prepare("DELETE FROM user_channels WHERE user_id=?")->execute([$uid]);
        $stmt = db()->prepare("INSERT IGNORE INTO user_channels (user_id,channel_id) VALUES (?,?)");
        foreach ((array)$ids as $cid) {
            $stmt->execute([$uid, intval($cid)]);
        }
        jsonResponse(['ok'=>true]);

    case 'admin_leads':
        if (!isAdmin()) jsonResponse(['error' => 'Доступ запрещён'], 403);
        $leads = db()->query("SELECT * FROM leads ORDER BY created_at DESC")->fetchAll();
        jsonResponse(['ok'=>true,'leads'=>$leads]);

    default:
        jsonResponse(['error' => 'Неизвестное действие'], 400);
}
